# Project-specific ProGuard / R8 rules.
# Compose and AndroidX ship their own consumer rules.
