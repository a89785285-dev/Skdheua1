// AppIcon: iOS-style squircle tile with drawn artwork, soft shadow and label.
package com.vanta.ioslauncher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

data class AppItem(
    val label: String,
    val glyph: String,
    val color: Color,
    val target: Class<*>
)

// Superellipse (n = 5) that approximates the iOS continuous-corner squircle.
val IosSquircle: Shape = GenericShape { size, _ ->
    val cx = size.width / 2.0
    val cy = size.height / 2.0
    val radius = size.width / 2.0
    val exponent = 0.4
    val steps = 120
    for (i in 0..steps) {
        val t = 2.0 * Math.PI * i / steps
        val c = cos(t)
        val s = sin(t)
        val x = cx + radius * Math.signum(c) * Math.pow(abs(c), exponent)
        val y = cy + radius * Math.signum(s) * Math.pow(abs(s), exponent)
        if (i == 0) moveTo(x.toFloat(), y.toFloat()) else lineTo(x.toFloat(), y.toFloat())
    }
    close()
}

private val drawnLabels = setOf("Messages", "Safari", "Calculator", "Settings", "Photos")

@Composable
fun AppIcon(
    item: AppItem,
    onClick: (AppItem) -> Unit,
    modifier: Modifier = Modifier,
    showLabel: Boolean = true
) {
    val baseColor = if (item.label == "Photos") Color.White else item.color
    val fill = Brush.verticalGradient(listOf(lerp(baseColor, Color.White, 0.12f), baseColor))

    Column(
        modifier = modifier
            .width(if (showLabel) 72.dp else 60.dp)
            .clickable { onClick(item) },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .shadow(elevation = 5.dp, shape = IosSquircle)
                .clip(IosSquircle)
                .background(fill),
            contentAlignment = Alignment.Center
        ) {
            IconArt(label = item.label, glyph = item.glyph, baseColor = baseColor)
        }
        if (showLabel) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = item.label,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = TextStyle(
                    shadow = Shadow(color = Color(0x99000000), offset = Offset(0f, 1f), blurRadius = 3f)
                )
            )
        }
    }
}

@Composable
private fun IconArt(label: String, glyph: String, baseColor: Color) {
    if (label in drawnLabels) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            when (label) {
                "Messages" -> drawMessages()
                "Safari" -> drawSafari()
                "Calculator" -> drawCalculator()
                "Settings" -> drawSettings(baseColor)
                "Photos" -> drawPhotos()
                else -> Unit
            }
        }
    } else {
        Text(text = glyph, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium)
    }
}

private fun DrawScope.drawMessages() {
    val w = size.width
    val h = size.height
    drawRoundRect(
        color = Color.White,
        topLeft = Offset(w * 0.2f, h * 0.26f),
        size = Size(w * 0.6f, h * 0.46f),
        cornerRadius = CornerRadius(w * 0.22f)
    )
    drawPath(
        path = Path().apply {
            moveTo(w * 0.32f, h * 0.66f)
            lineTo(w * 0.31f, h * 0.8f)
            lineTo(w * 0.47f, h * 0.7f)
            close()
        },
        color = Color.White
    )
}

private fun DrawScope.drawSafari() {
    val c = Offset(size.width / 2f, size.height / 2f)
    val r = size.width * 0.36f
    drawCircle(
        color = Color.White,
        radius = r,
        center = c,
        style = Stroke(width = size.width * 0.04f)
    )
    rotate(degrees = 45f, pivot = c) {
        val len = r * 0.86f
        val half = r * 0.2f
        drawPath(
            path = Path().apply {
                moveTo(c.x, c.y - len)
                lineTo(c.x + half, c.y)
                lineTo(c.x - half, c.y)
                close()
            },
            color = Color(0xFFFF453A)
        )
        drawPath(
            path = Path().apply {
                moveTo(c.x, c.y + len)
                lineTo(c.x + half, c.y)
                lineTo(c.x - half, c.y)
                close()
            },
            color = Color.White
        )
    }
}

private fun DrawScope.drawCalculator() {
    val w = size.width
    val h = size.height
    val cell = w * 0.15f
    for (row in 0 until 4) {
        for (col in 0 until 4) {
            drawCircle(
                color = if (col == 3) Color(0xFFFF9F0A) else Color(0xFF636366),
                radius = cell * 0.42f,
                center = Offset(w * 0.2f + cell * (col + 0.5f), h * 0.2f + cell * (row + 0.5f))
            )
        }
    }
}

private fun DrawScope.drawSettings(baseColor: Color) {
    val c = Offset(size.width / 2f, size.height / 2f)
    val bodyR = size.width * 0.26f
    val toothOuter = size.width * 0.4f
    val toothW = size.width * 0.14f
    for (i in 0 until 8) {
        rotate(degrees = i * 45f, pivot = c) {
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(c.x - toothW / 2f, c.y - toothOuter),
                size = Size(toothW, toothOuter - bodyR * 0.7f),
                cornerRadius = CornerRadius(toothW / 3f)
            )
        }
    }
    drawCircle(color = Color.White, radius = bodyR, center = c)
    drawCircle(color = baseColor, radius = bodyR * 0.45f, center = c)
}

private fun DrawScope.drawPhotos() {
    val c = Offset(size.width / 2f, size.height / 2f)
    val petalW = size.width * 0.19f
    val petalH = size.width * 0.27f
    val petalColors = listOf(
        Color(0xFFFFCC00),
        Color(0xFFFF9500),
        Color(0xFFFF3B30),
        Color(0xFFFF2D55),
        Color(0xFFAF52DE),
        Color(0xFF007AFF),
        Color(0xFF5AC8FA),
        Color(0xFF34C759)
    )
    petalColors.forEachIndexed { i, color ->
        rotate(degrees = i * 45f, pivot = c) {
            drawOval(
                color = color,
                topLeft = Offset(c.x - petalW / 2f, c.y - size.width * 0.42f),
                size = Size(petalW, petalH)
            )
        }
    }
}
