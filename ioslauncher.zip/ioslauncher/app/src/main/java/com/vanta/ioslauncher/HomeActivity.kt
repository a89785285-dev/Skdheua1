// HomeActivity: launcher entry point (HOME intent).
package com.vanta.ioslauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.graphics.Color
import com.vanta.ioslauncher.apps.CalculatorActivity
import com.vanta.ioslauncher.apps.MessagesActivity
import com.vanta.ioslauncher.apps.PhotosActivity
import com.vanta.ioslauncher.apps.SafariActivity
import com.vanta.ioslauncher.apps.SettingsActivity
import com.vanta.ioslauncher.ui.AppItem
import com.vanta.ioslauncher.ui.Notice
import com.vanta.ioslauncher.ui.SpringBoard
import com.vanta.ioslauncher.ui.theme.IosLauncherTheme

private val homeApps = listOf(
    AppItem("Safari", "S", Color(0xFF0A84FF), SafariActivity::class.java),
    AppItem("Messages", "M", Color(0xFF30D158), MessagesActivity::class.java),
    AppItem("Photos", "P", Color(0xFFFF9F0A), PhotosActivity::class.java),
    AppItem("Settings", "St", Color(0xFF8E8E93), SettingsActivity::class.java),
    AppItem("Calculator", "=", Color(0xFF2C2C2E), CalculatorActivity::class.java)
)

private val sampleNotices = listOf(
    Notice("Messages", "Launcher", "Home screen is running.")
)

class HomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            IosLauncherTheme {
                SpringBoard(
                    apps = homeApps,
                    dock = homeApps.take(4),
                    notices = sampleNotices
                )
            }
        }
    }
}
