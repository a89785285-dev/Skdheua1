// StatusBar: iOS-style status bar with clock, Dynamic Island and drawn system icons.
package com.vanta.ioslauncher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

private val clockFormat = DateTimeFormatter.ofPattern("H:mm")

@Composable
fun StatusBar(modifier: Modifier = Modifier) {
    val now by produceState(initialValue = LocalTime.now()) {
        while (true) {
            value = LocalTime.now()
            delay(1_000L)
        }
    }

    Box(modifier = modifier.fillMaxWidth().height(54.dp)) {
        Text(
            text = now.format(clockFormat),
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 17.sp,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 34.dp)
        )
        DynamicIsland(modifier = Modifier.align(Alignment.TopCenter).padding(top = 11.dp))
        Row(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 28.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SignalIcon()
            WifiIcon()
            BatteryIcon()
        }
    }
}

@Composable
private fun DynamicIsland(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(width = 126.dp, height = 37.dp)
            .clip(RoundedCornerShape(19.dp))
            .background(Color.Black)
    )
}

@Composable
private fun SignalIcon() {
    Canvas(modifier = Modifier.size(18.dp, 12.dp)) {
        val barWidth = size.width * 0.2f
        val gap = (size.width - barWidth * 4f) / 3f
        listOf(0.35f, 0.55f, 0.75f, 1f).forEachIndexed { index, fraction ->
            val barHeight = size.height * fraction
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(index * (barWidth + gap), size.height - barHeight),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth * 0.3f)
            )
        }
    }
}

@Composable
private fun WifiIcon() {
    Canvas(modifier = Modifier.size(16.dp, 12.dp)) {
        val origin = Offset(size.width / 2f, size.height * 0.95f)
        listOf(0.5f, 0.75f, 1f).forEach { fraction ->
            val radius = size.width * 0.5f * fraction
            drawArc(
                color = Color.White,
                startAngle = 225f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = Offset(origin.x - radius, origin.y - radius),
                size = Size(radius * 2f, radius * 2f),
                style = Stroke(width = size.width * 0.13f, cap = StrokeCap.Round)
            )
        }
        drawCircle(
            color = Color.White,
            radius = size.width * 0.09f,
            center = Offset(origin.x, origin.y - size.width * 0.02f)
        )
    }
}

@Composable
private fun BatteryIcon() {
    Canvas(modifier = Modifier.size(26.dp, 13.dp)) {
        val bodyWidth = size.width * 0.9f
        val bodyHeight = size.height
        val inset = bodyHeight * 0.18f
        drawRoundRect(
            color = Color.White.copy(alpha = 0.4f),
            size = Size(bodyWidth, bodyHeight),
            cornerRadius = CornerRadius(bodyHeight * 0.3f),
            style = Stroke(width = bodyHeight * 0.08f)
        )
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(inset, inset),
            size = Size((bodyWidth - inset * 2f) * 0.8f, bodyHeight - inset * 2f),
            cornerRadius = CornerRadius(bodyHeight * 0.14f)
        )
        drawRoundRect(
            color = Color.White.copy(alpha = 0.4f),
            topLeft = Offset(bodyWidth + size.width * 0.02f, bodyHeight * 0.3f),
            size = Size(size.width * 0.06f, bodyHeight * 0.4f),
            cornerRadius = CornerRadius(size.width * 0.03f)
        )
    }
}
