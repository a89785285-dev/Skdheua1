// Dock: frosted glass tray with four pinned apps, icons only, like iOS.
package com.vanta.ioslauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DockShape = RoundedCornerShape(34.dp)
private val DockGlass = Brush.verticalGradient(listOf(Color(0x59FFFFFF), Color(0x26FFFFFF)))

@Composable
fun Dock(
    items: List<AppItem>,
    onClick: (AppItem) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp)
            .clip(DockShape)
            .background(DockGlass)
            .border(width = 0.5.dp, color = Color(0x55FFFFFF), shape = DockShape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { AppIcon(item = it, onClick = onClick, showLabel = false) }
    }
}
