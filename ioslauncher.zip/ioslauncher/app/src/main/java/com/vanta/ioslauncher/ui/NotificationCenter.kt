// NotificationCenter: full-screen overlay listing recent notices.
package com.vanta.ioslauncher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vanta.ioslauncher.ui.theme.IosBlue
import com.vanta.ioslauncher.ui.theme.IosWallpaper

data class Notice(val app: String, val title: String, val body: String)

@Composable
fun NotificationCenter(
    visible: Boolean,
    notices: List<Notice>,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn() + slideInVertically { -it },
        exit = fadeOut() + slideOutVertically { -it }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(IosWallpaper.copy(alpha = 0.97f))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Notifications", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 20.sp)
                Text(
                    text = "Close",
                    color = IosBlue,
                    modifier = Modifier.clickable(onClick = onDismiss)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))

            if (notices.isEmpty()) {
                Text("No notifications", color = Color.White.copy(alpha = 0.6f))
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(notices) { notice -> NoticeRow(notice) }
                }
            }
        }
    }
}

@Composable
private fun NoticeRow(notice: Notice) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(12.dp)
    ) {
        Text(notice.app.uppercase(), color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
        Text(notice.title, color = Color.White, fontWeight = FontWeight.SemiBold)
        Text(notice.body, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
    }
}
