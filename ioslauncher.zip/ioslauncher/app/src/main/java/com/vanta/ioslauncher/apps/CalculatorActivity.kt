// CalculatorActivity: placeholder screen for the Calculator app.
package com.vanta.ioslauncher.apps

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Text
import androidx.compose.ui.unit.sp
import com.vanta.ioslauncher.ui.AppScaffold
import com.vanta.ioslauncher.ui.theme.IosLauncherTheme
import com.vanta.ioslauncher.ui.theme.IosSecondaryText

class CalculatorActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            IosLauncherTheme {
                AppScaffold(title = "Calculator", onBack = { finish() }) {
                    Text("Coming soon", color = IosSecondaryText, fontSize = 17.sp)
                }
            }
        }
    }
}
