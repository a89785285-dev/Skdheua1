// LockScreenActivity: lock screen shown before the home screen.
package com.vanta.ioslauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vanta.ioslauncher.ui.theme.IosLauncherTheme
import com.vanta.ioslauncher.ui.theme.IosWallpaper
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.delay

class LockScreenActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            IosLauncherTheme {
                LockScreen(onUnlock = { finish() })
            }
        }
    }
}

@Composable
private fun LockScreen(onUnlock: () -> Unit) {
    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(1_000L)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IosWallpaper)
            .clickable(onClick = onUnlock)
            .padding(top = 96.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = now.format(DateTimeFormatter.ofPattern("EEEE d MMMM", Locale.getDefault())),
            color = Color.White,
            fontSize = 18.sp
        )
        Text(
            text = now.format(DateTimeFormatter.ofPattern("HH:mm")),
            color = Color.White,
            fontSize = 96.sp,
            fontWeight = FontWeight.Light
        )
        Spacer(modifier = Modifier.weight(1f))
        Text(
            text = "Tap to unlock",
            color = Color.White.copy(alpha = 0.7f),
            modifier = Modifier.padding(bottom = 48.dp)
        )
    }
}
