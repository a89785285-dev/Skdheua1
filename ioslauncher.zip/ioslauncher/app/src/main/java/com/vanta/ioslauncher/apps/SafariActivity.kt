// SafariActivity: placeholder screen for the Safari app.
package com.vanta.ioslauncher.apps

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vanta.ioslauncher.ui.theme.IosBlue
import com.vanta.ioslauncher.ui.theme.IosLauncherTheme
import com.vanta.ioslauncher.ui.theme.IosWallpaper

class SafariActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IosLauncherTheme {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(IosWallpaper)
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Safari", color = Color.White, fontSize = 28.sp)
                    Text(
                        text = "Back",
                        color = IosBlue,
                        modifier = Modifier
                            .padding(top = 24.dp)
                            .clickable { finish() }
                    )
                }
            }
        }
    }
}
