// ControlCenter: iOS-style panel with connectivity toggles and sliders, opened by swiping down from the top-right.
package com.vanta.ioslauncher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vanta.ioslauncher.ui.theme.IosBlue
import com.vanta.ioslauncher.ui.theme.IosSecondaryText

private enum class Tile(val title: String) {
    Airplane("Airplane"),
    Wifi("Wi-Fi"),
    Bluetooth("Bluetooth"),
    Focus("Focus")
}

private val PanelColor = Color(0xE61C1C1E)
private val CardColor = Color(0xFF2C2C2E)
private val TileOff = Color(0xFF545458)

@Composable
fun ControlCenter(
    visible: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val toggles = remember {
        mutableStateMapOf<Tile, Boolean>(
            Tile.Airplane to false,
            Tile.Wifi to true,
            Tile.Bluetooth to true,
            Tile.Focus to false
        )
    }
    var brightness by remember { mutableFloatStateOf(0.7f) }
    var volume by remember { mutableFloatStateOf(0.5f) }
    val sliderColors = SliderDefaults.colors(
        thumbColor = Color.White,
        activeTrackColor = Color.White,
        inactiveTrackColor = Color(0x59787880)
    )
    val tileRows = listOf(Tile.Airplane, Tile.Wifi, Tile.Bluetooth, Tile.Focus).chunked(2)

    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn() + slideInVertically { -it },
        exit = fadeOut() + slideOutVertically { -it }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x80000000))
                .clickable(onClick = onDismiss)
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(start = 10.dp, end = 10.dp, top = 58.dp)
                    .clip(RoundedCornerShape(36.dp))
                    .background(PanelColor)
                    .clickable(onClick = {})
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(26.dp))
                        .background(CardColor)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    tileRows.forEach { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            pair.forEach { tile ->
                                ToggleTile(
                                    tile = tile,
                                    on = toggles[tile] == true,
                                    onToggle = { toggles[tile] = toggles[tile] != true },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(26.dp))
                        .background(CardColor)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(text = "Brightness", color = IosSecondaryText, fontSize = 13.sp)
                    Slider(
                        value = brightness,
                        onValueChange = { brightness = it },
                        colors = sliderColors
                    )
                    Text(text = "Volume", color = IosSecondaryText, fontSize = 13.sp)
                    Slider(
                        value = volume,
                        onValueChange = { volume = it },
                        colors = sliderColors
                    )
                }
            }
        }
    }
}

@Composable
private fun ToggleTile(
    tile: Tile,
    on: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = when (tile) {
        Tile.Airplane -> Color(0xFFFF9F0A)
        Tile.Focus -> Color(0xFF5E5CE6)
        else -> IosBlue
    }
    val badge = if (on) accent else TileOff

    Row(
        modifier = modifier
            .clickable(onClick = onToggle)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(badge),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(20.dp)) {
                drawTileGlyph(tile, badge)
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = tile.title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
            Text(
                text = if (on) "On" else "Off",
                color = IosSecondaryText,
                fontSize = 12.sp
            )
        }
    }
}

private fun DrawScope.fillPolygon(color: Color, vararg points: Pair<Float, Float>) {
    val path = Path()
    points.forEachIndexed { index, (fx, fy) ->
        val x = size.width * fx
        val y = size.height * fy
        if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path = path, color = color)
}

private fun DrawScope.drawTileGlyph(tile: Tile, cut: Color) {
    val w = size.width
    val h = size.height
    when (tile) {
        Tile.Airplane -> fillPolygon(
            Color.White,
            0.44f to 0.1f, 0.56f to 0.1f, 0.56f to 0.42f, 0.94f to 0.6f, 0.94f to 0.7f,
            0.56f to 0.6f, 0.56f to 0.84f, 0.66f to 0.92f, 0.66f to 0.97f, 0.5f to 0.93f,
            0.34f to 0.97f, 0.34f to 0.92f, 0.44f to 0.84f, 0.44f to 0.6f, 0.06f to 0.7f,
            0.06f to 0.6f, 0.44f to 0.42f
        )
        Tile.Wifi -> {
            val origin = Offset(w / 2f, h * 0.95f)
            listOf(0.5f, 0.75f, 1f).forEach { fraction ->
                val radius = w * 0.5f * fraction
                drawArc(
                    color = Color.White,
                    startAngle = 225f,
                    sweepAngle = 90f,
                    useCenter = false,
                    topLeft = Offset(origin.x - radius, origin.y - radius),
                    size = Size(radius * 2f, radius * 2f),
                    style = Stroke(width = w * 0.13f, cap = StrokeCap.Round)
                )
            }
            drawCircle(
                color = Color.White,
                radius = w * 0.09f,
                center = Offset(origin.x, origin.y - w * 0.02f)
            )
        }
        Tile.Bluetooth -> {
            val path = Path().apply {
                moveTo(w * 0.3f, h * 0.35f)
                lineTo(w * 0.7f, h * 0.7f)
                lineTo(w * 0.5f, h * 0.9f)
                lineTo(w * 0.5f, h * 0.1f)
                lineTo(w * 0.7f, h * 0.3f)
                lineTo(w * 0.3f, h * 0.65f)
            }
            drawPath(
                path = path,
                color = Color.White,
                style = Stroke(width = w * 0.1f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
        Tile.Focus -> {
            drawCircle(color = Color.White, radius = w * 0.36f, center = Offset(w * 0.5f, h * 0.5f))
            drawCircle(color = cut, radius = w * 0.3f, center = Offset(w * 0.66f, h * 0.42f))
        }
    }
}
