// Launcher color tokens and theme wrapper.
package com.vanta.ioslauncher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val IosBlue = Color(0xFF0A84FF)
val IosWallpaper = Color(0xFF1B2A4A)

private val LauncherColors = darkColorScheme(
    primary = IosBlue,
    background = IosWallpaper,
    surface = Color(0x33FFFFFF),
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun IosLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LauncherColors, content = content)
}
