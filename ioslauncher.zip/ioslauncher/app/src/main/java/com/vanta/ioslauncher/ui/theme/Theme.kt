// Launcher color tokens, iOS wallpaper gradient and theme wrapper.
package com.vanta.ioslauncher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val IosBlue = Color(0xFF0A84FF)
val IosWallpaper = Color(0xFF1B2A4A)
val IosBackground = Color(0xFF000000)
val IosSecondaryText = Color(0x99EBEBF5)

val IosHomeWallpaper: Brush = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF2E3B8F),
        Color(0xFF5A2D8C),
        Color(0xFF1B1846),
        Color(0xFF0B0B1E)
    )
)

private val LauncherColors = darkColorScheme(
    primary = IosBlue,
    background = IosBackground,
    surface = Color(0x33FFFFFF),
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun IosLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LauncherColors, content = content)
}
