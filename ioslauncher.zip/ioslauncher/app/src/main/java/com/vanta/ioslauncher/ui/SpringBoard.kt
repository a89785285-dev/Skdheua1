// SpringBoard: home screen grid, dock, status bar and overlays.
package com.vanta.ioslauncher.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vanta.ioslauncher.ui.theme.IosWallpaper

@Composable
fun SpringBoard(
    apps: List<AppItem>,
    dock: List<AppItem>,
    notices: List<Notice>
) {
    val context = LocalContext.current
    var showNotifications by remember { mutableStateOf(false) }
    var showControl by remember { mutableStateOf(false) }

    val launch: (AppItem) -> Unit = { item ->
        context.startActivity(Intent(context, item.target))
    }

    Box(modifier = Modifier.fillMaxSize().background(IosWallpaper)) {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
            StatusBar(onClick = { showNotifications = true })

            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                items(apps) { item -> AppIcon(item = item, onClick = launch) }
            }

            Dock(items = dock, onClick = launch)

            Text(
                text = "Control Center",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 8.dp)
                    .clickable { showControl = true }
            )
        }

        ControlCenter(
            visible = showControl,
            onDismiss = { showControl = false },
            modifier = Modifier.align(Alignment.TopCenter)
        )

        NotificationCenter(
            visible = showNotifications,
            notices = notices,
            onDismiss = { showNotifications = false },
            modifier = Modifier.fillMaxSize()
        )
    }
}
