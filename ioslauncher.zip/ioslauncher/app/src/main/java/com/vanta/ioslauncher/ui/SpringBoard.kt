// SpringBoard: iOS home screen with paged icon grid, dock, page dots and swipe-down overlays.
package com.vanta.ioslauncher.ui

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.vanta.ioslauncher.ui.theme.IosHomeWallpaper

private const val ICONS_PER_PAGE = 20
private const val ICON_COLUMNS = 4

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SpringBoard(
    apps: List<AppItem>,
    dock: List<AppItem>,
    notices: List<Notice>
) {
    ImmersiveSystemBars()

    val context = LocalContext.current
    val density = LocalDensity.current
    val configuration = LocalConfiguration.current
    val screenWidthPx = with(density) { configuration.screenWidthDp.dp.toPx() }
    val pullThresholdPx = with(density) { 90.dp.toPx() }

    var showNotifications by remember { mutableStateOf(false) }
    var showControl by remember { mutableStateOf(false) }

    val pages = remember(apps) { apps.chunked(ICONS_PER_PAGE) }
    val pagerState = rememberPagerState(pageCount = { maxOf(pages.size, 1) })

    val launch: (AppItem) -> Unit = { item ->
        context.startActivity(Intent(context, item.target))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(IosHomeWallpaper)
            .pointerInput(screenWidthPx, pullThresholdPx) {
                var startX = 0f
                var totalDy = 0f
                detectVerticalDragGestures(
                    onDragStart = { offset ->
                        startX = offset.x
                        totalDy = 0f
                    },
                    onDragEnd = {
                        if (totalDy > pullThresholdPx) {
                            if (startX > screenWidthPx / 2f) {
                                showControl = true
                            } else {
                                showNotifications = true
                            }
                        }
                    },
                    onDragCancel = { totalDy = 0f },
                    onVerticalDrag = { change, dragAmount ->
                        change.consume()
                        totalDy += dragAmount
                    }
                )
            }
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            StatusBar()

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) { page ->
                IconPage(items = pages.getOrElse(page) { emptyList() }, onLaunch = launch)
            }

            if (pages.size > 1) {
                PageDots(current = pagerState.currentPage, count = pages.size)
            }

            Dock(items = dock, onClick = launch)
            HomeIndicator()
        }

        ControlCenter(
            visible = showControl,
            onDismiss = { showControl = false },
            modifier = Modifier.fillMaxSize()
        )

        NotificationCenter(
            visible = showNotifications,
            notices = notices,
            onDismiss = { showNotifications = false },
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun IconPage(items: List<AppItem>, onLaunch: (AppItem) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items.chunked(ICON_COLUMNS).forEach { rowItems ->
            Row(modifier = Modifier.fillMaxWidth()) {
                repeat(ICON_COLUMNS) { column ->
                    Box(
                        modifier = Modifier.weight(1f),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        rowItems.getOrNull(column)?.let { item ->
                            AppIcon(item = item, onClick = onLaunch)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PageDots(current: Int, count: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.Center
    ) {
        repeat(count) { index ->
            Box(
                modifier = Modifier
                    .padding(horizontal = 3.dp)
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (index == current) Color.White else Color.White.copy(alpha = 0.4f))
            )
        }
    }
}

@Composable
private fun HomeIndicator() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp, bottom = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .width(134.dp)
                .height(5.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color.White)
        )
    }
}
